package com.projet.firas.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.projet.firas.DatabaseManager;

@WebServlet("/EmailServlet")
public class EmailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<String> emailList = getEmailListFromDatabase();

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Liste des adresses email</title></head><body>");
        out.println("<h2>Liste des adresses email :</h2>");

        for (String email : emailList) {
            out.println("<p>" + email + "</p>");
        }

        out.println("<h2>Inscription/Désinscription :</h2>");
        out.println("<form action=\"EmailServlet\" method=\"post\">");
        out.println("   <label for=\"email\">Adresse e-mail :</label>");
        out.println("   <input type=\"text\" id=\"email\" name=\"email\" required>");
        out.println("   <button type=\"submit\" name=\"action\" value=\"subscribe\">Subscribe</button>");
        out.println("   <button type=\"submit\" name=\"action\" value=\"unsubscribe\">Unsubscribe</button>");
        out.println("</form>");

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String email = request.getParameter("email");

        if ("subscribe".equals(action)) {
            addEmailToDatabase(email);
        } else if ("unsubscribe".equals(action)) {
            removeEmailFromDatabase(email);
        }

        response.sendRedirect("EmailServlet");
    }

    private ArrayList<String> getEmailListFromDatabase() {
        ArrayList<String> emailList = new ArrayList<>();
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT email FROM email_list");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                emailList.add(resultSet.getString("email"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emailList;
    }

    private void addEmailToDatabase(String email) {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO email_list (email) VALUES (?)")) {

            preparedStatement.setString(1, email);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void removeEmailFromDatabase(String email) {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM email_list WHERE email = ?")) {

            preparedStatement.setString(1, email);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
